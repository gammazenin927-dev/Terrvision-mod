# Terrvision — Project Bible

> Tempel (atau unggah) dokumen ini di awal setiap chat baru bersama source terbaru, supaya Claude punya konteks penuh.
> Claude tidak membawa ingatan antar-percakapan.

## 1. Lore (kanon)

- **Tahun 4009.** 59% populasi manusia telah hilang.
- **Vlight**: mineral energi berwarna kuning. Sumber energi bot, senjata, dan semua teknologi, sekaligus barang dagang
  bernilai. Tumbuh di gua, butuh **100 tahun** untuk matang penuh, rata-rata **128 kg** per bongkah (sangat berat).
- **Terrvision**: robot penambang Vlight buatan **Roosevelt Industrial** (perusahaan yang memproduksi banyak robot publik).
  Daya angkut maksimum **500 kg**. Kubus Vlight di kantongnya dipakai untuk **transaksi kecil tangan-ke-tangan**.
- **Great Invasion**: invasi alien. Alien (**Dark Legion**) menguasai planet.
- Terrvision selamat karena AI-nya **berevolusi** menjadi lebih cerdas; ia menambang Vlight demi bertahan hidup.
- Roosevelt bangkrut setelah insiden. Manusia menyusut menjadi komunitas bertahan hidup bernama **The Tech**.
  Alien mengabaikan mereka (meremehkan semangat manusia).
- ⚠️ **Asumsi belum dikonfirmasi:** Great Invasion terjadi sekitar 139 tahun sebelum 4009 (≈ tahun 3870).
  Efek samping bagus: 139 > 100, jadi Vlight sudah tumbuh ulang minimal sekali sejak invasi.

## 2. Spesifikasi Entity v0.1

| Aspek | Nilai |
|---|---|
| Basis | `MerchantEntity` (vanilla) + `GeoEntity` (GeckoLib) |
| Hitbox | 1.25 × 2.0 (model 1:1, tinggi 2.0 blok; lengan membuat visual lebih lebar dari hitbox) |
| Perilaku | berkeliaran; **berhenti & menghadap pemain di jarak ≤ 2.5 blok** (lepas di > 3.5); klik kanan = layar trade |
| Animasi | `idle` (loop), `walk` (loop), `shop` (hold on last frame; main selama trading, lalu kembali ke idle/walk) |
| Suara | `hit` (terkena damage & mati), `shop` (saat trade dibuka), `walk` (diulang tiap 55 tick saat bergerak) |
| Spawn | spawn egg + natural spawn **hanya di dalam mineshaft** (tag `#terrvision:terrvision_spawn_structures`) |
| Despawn | tidak despawn karena jarak (seperti hewan) |
| Trade | `data/terrvision/trades/terrvision.json` (mata uang sementara: emerald) |

## 3. Stack

Minecraft **1.21.1**, Fabric Loader 0.16.10, Fabric API 0.116.10+1.21.1, Yarn `1.21.1+build.3`, **GeckoLib 4.7.3**, Java 21,
Fabric Loom 1.9, Gradle 8.12. Mod id: `terrvision`. Package: `com.terrvision`.
Target pemain: MojoLauncher (Android, berbasis PojavLauncher; mendukung Fabric).

## 4. Konvensi arsitektur

- **Client/server dipisah.** Semua yang menyentuh rendering hanya ada di `client/` (`TerrvisionClient`, `TerrvisionRenderer`).
  Satu-satunya state yang disinkronkan ke client adalah `TRADING` (DataTracker) untuk animasi shop.
- **Registrasi** lewat kelas `registry/Mod*` (Entities, Items, Sounds, Spawns); urutan di `Terrvision#onInitialize` penting.
- **Tidak ada angka ajaib**: semua konstanta entity ada di `entity/TerrvisionTuning`.
- **Data-driven**: trade (JSON), struktur spawn (tag), suara (`sounds.json`), teks (`lang`). Menambah barang dagangan
  tidak perlu mengompilasi ulang.
- **Tidak ada alokasi/IO per tick.** Trade dibaca sekali per entity (lazy). Goal melepas referensi pemain di `stop()`.
- Nama animasi harus persis: `animation.terrvision.idle|walk|shop`.

## 5. Peta file

```
src/main/java/com/terrvision/
  Terrvision.java                 entrypoint umum
  registry/  ModEntities | ModItems | ModSounds | ModSpawns
  entity/    TerrvisionEntity | TerrvisionTuning
  entity/ai/ FacePlayerGoal
  trade/     TradeDefinition (codec) | TerrvisionTrades (loader)
  client/    TerrvisionClient ; client/render/TerrvisionRenderer
src/main/resources/
  fabric.mod.json, terrvision.accesswidener
  assets/terrvision/  geo/entity/terrvision.geo.json
                      animations/entity/terrvision.animation.json   (gabungan idle+walk+shop)
                      textures/entity/terrvision.png ; textures/item/terrvision_spawn_egg.png
                      models/item/terrvision_spawn_egg.json ; sounds.json ; sounds/entity/*.ogg (mono) ; lang/en_us.json
  data/terrvision/    trades/terrvision.json ; tags/worldgen/structure/terrvision_spawn_structures.json
```

## 6. Pipeline aset (Blockbench → mod)

1. Ekspor model Bedrock (`.geo.json`) → `geo/entity/terrvision.geo.json`.
2. Ekspor animasi → gabungkan ke satu `terrvision.animation.json` (key `animation.terrvision.<nama>`).
3. Texture 128×128 → `textures/entity/terrvision.png`.
4. Suara harus **mono** `.ogg` (Vorbis); stereo tidak punya jarak/arah di Minecraft.

## 7. Build (termasuk dari HP)

- **Dari HP (tanpa PC):** buat repo GitHub, unggah seluruh isi folder ini (termasuk `.github/`), lalu buka tab **Actions** →
  workflow "Build mod jar" → unduh artifact `terrvision-jar` (pakai jar **tanpa** `-sources`).
- **Dari PC:** `gradle build` (atau buat wrapper dengan `gradle wrapper --gradle-version 8.12`); hasil di `build/libs/`.
- **Di game:** satu instance Fabric 1.21.1 berisi: `terrvision-0.1.0.jar` + **Fabric API** + **GeckoLib 4.7.3 (Fabric, 1.21.1)**.

## 8. Status & risiko

- Kode **belum pernah dikompilasi** (lingkungan penulisan tidak punya jaringan). API sudah dicocokkan dengan Javadoc Yarn
  1.21.1+build.3 dan dokumentasi GeckoLib 4, tetapi build pertama bisa saja menampilkan error kecil. Kirim log-nya ke Claude.
- `SpawnRestriction#register` bersifat private di Yarn → dibuka lewat `terrvision.accesswidener`.
- Belum ada: animasi serang/mati/terluka, head-tracking, suara kematian khusus, loot drop.
- Natural spawn memakai entri bioma + prediket struktur; efek ke spawn hewan vanilla di permukaan dibuat sekecil mungkin
  (bobot rendah). Alternatif lebih bersih: Mixin ke daftar spawn per-struktur.
- Belum diuji di renderer mobile (GL4ES/ANGLE); model 54 bone seharusnya ringan.

## 9. Roadmap yang diusulkan

1. Blok Vlight + item **Vlight Cube** → ganti mata uang trade dari emerald ke `terrvision:vlight_cube` (cukup edit JSON).
2. Entity/struktur untuk **The Tech** dan **Dark Legion**; Terrvision bereaksi (kabur) terhadap ancaman.
3. Penyampaian lore di dalam game: nama trade, tooltip item, advancement, item "data log".
4. Pindah ke `terrvision-datagen` bila jumlah aset membesar.
