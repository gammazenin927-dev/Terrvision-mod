package com.terrvision;

import com.terrvision.registry.ModEntities;
import com.terrvision.registry.ModItems;
import com.terrvision.registry.ModSounds;
import com.terrvision.registry.ModSpawns;
import net.fabricmc.api.ModInitializer;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Common (client + server) entrypoint. Contains no client-only code; rendering lives in
 * {@link com.terrvision.client.TerrvisionClient}.
 */
public final class Terrvision implements ModInitializer {

    public static final String MOD_ID = "terrvision";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    /** Builds an {@link Identifier} in this mod's namespace. */
    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        // Order matters: sounds -> entity type (+ attributes) -> items (the spawn egg needs the type) -> spawn rules.
        ModSounds.init();
        ModEntities.init();
        ModItems.init();
        ModSpawns.init();
        LOGGER.info("Terrvision initialised");
    }
}
