package com.terrvision.trade;

import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import com.mojang.serialization.Codec;
import com.mojang.serialization.JsonOps;
import com.terrvision.Terrvision;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.List;
import java.util.Optional;
import net.minecraft.registry.RegistryOps;
import net.minecraft.resource.Resource;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.village.TradeOffer;

/**
 * Loads Terrvision's stock from {@code data/terrvision/trades/terrvision.json}.
 *
 * <p>The file is read once per entity (when its offers are first requested), not on every tick or interaction,
 * so there is no per-tick cost and no cached state that could go stale after {@code /reload}. A datapack can
 * override the file to change the stock.
 */
public final class TerrvisionTrades {

    private static final Identifier TRADES_FILE = Terrvision.id("trades/terrvision.json");
    private static final Codec<List<TradeDefinition>> FILE_CODEC =
            TradeDefinition.CODEC.listOf().fieldOf("trades").codec();

    private TerrvisionTrades() {
    }

    /** @return the configured offers, or an empty list (and an error in the log) if the file is missing or invalid. */
    public static List<TradeOffer> load(ServerWorld world) {
        Optional<Resource> resource = world.getServer().getResourceManager().getResource(TRADES_FILE);
        if (resource.isEmpty()) {
            Terrvision.LOGGER.error("Trade file {} is missing; Terrvision will have nothing to sell", TRADES_FILE);
            return List.of();
        }

        try (BufferedReader reader = resource.get().getReader()) {
            JsonElement json = JsonParser.parseReader(reader);
            // Registry-aware ops, so trades can also use enchantments and other registry-backed components.
            RegistryOps<JsonElement> ops = RegistryOps.of(JsonOps.INSTANCE, world.getRegistryManager());
            return FILE_CODEC.parse(ops, json)
                    .resultOrPartial(error -> Terrvision.LOGGER.error("Invalid trade file {}: {}", TRADES_FILE, error))
                    .map(definitions -> definitions.stream().map(TradeDefinition::toOffer).toList())
                    .orElse(List.of());
        } catch (IOException | JsonParseException e) {
            Terrvision.LOGGER.error("Could not read trade file {}", TRADES_FILE, e);
            return List.of();
        }
    }
}
