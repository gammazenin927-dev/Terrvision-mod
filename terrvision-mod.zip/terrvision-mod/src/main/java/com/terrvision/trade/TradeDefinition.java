package com.terrvision.trade;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import net.minecraft.item.ItemStack;
import net.minecraft.village.TradeOffer;
import net.minecraft.village.TradedItem;

/**
 * One data-driven trade. JSON shape (all fields except {@code buy} and {@code sell} are optional):
 *
 * <pre>{@code
 * {
 *   "buy":        { "id": "minecraft:coal", "count": 24 },
 *   "buy_second": { "id": "minecraft:redstone", "count": 4 },
 *   "sell":       { "id": "minecraft:emerald", "count": 1 },
 *   "max_uses": 16, "xp": 2, "price_multiplier": 0.05
 * }
 * }</pre>
 */
public record TradeDefinition(
        TradedItem buy,
        Optional<TradedItem> buySecond,
        ItemStack sell,
        int maxUses,
        int experience,
        float priceMultiplier) {

    public static final Codec<TradeDefinition> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            TradedItem.CODEC.fieldOf("buy").forGetter(TradeDefinition::buy),
            TradedItem.CODEC.optionalFieldOf("buy_second").forGetter(TradeDefinition::buySecond),
            ItemStack.CODEC.fieldOf("sell").forGetter(TradeDefinition::sell),
            Codec.intRange(1, 9999).optionalFieldOf("max_uses", 12).forGetter(TradeDefinition::maxUses),
            Codec.intRange(0, 1000).optionalFieldOf("xp", 1).forGetter(TradeDefinition::experience),
            Codec.floatRange(0.0F, 1.0F).optionalFieldOf("price_multiplier", 0.05F)
                    .forGetter(TradeDefinition::priceMultiplier)
    ).apply(instance, TradeDefinition::new));

    /** Creates a fresh vanilla offer (the sell stack is copied so definitions are never mutated). */
    public TradeOffer toOffer() {
        return new TradeOffer(this.buy, this.buySecond, this.sell.copy(),
                this.maxUses, this.experience, this.priceMultiplier);
    }
}
