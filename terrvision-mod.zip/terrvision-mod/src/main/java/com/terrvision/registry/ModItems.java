package com.terrvision.registry;

import com.terrvision.Terrvision;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

/** Item registration. */
public final class ModItems {

    /**
     * Both colours are white on purpose: vanilla tints the egg's {@code layer0} with the primary colour,
     * and white is the identity tint, so the custom full-colour texture is shown untouched.
     */
    public static final Item TERRVISION_SPAWN_EGG = Registry.register(
            Registries.ITEM,
            Terrvision.id("terrvision_spawn_egg"),
            new SpawnEggItem(ModEntities.TERRVISION, 0xFFFFFF, 0xFFFFFF, new Item.Settings()));

    private ModItems() {
    }

    public static void init() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS)
                .register(entries -> entries.add(TERRVISION_SPAWN_EGG));
    }
}
