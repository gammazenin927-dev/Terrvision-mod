package com.terrvision.registry;

import com.terrvision.Terrvision;
import com.terrvision.entity.TerrvisionEntity;
import com.terrvision.entity.TerrvisionTuning;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.SpawnLocationTypes;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.Heightmap;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.gen.structure.Structure;

/**
 * Natural spawning: Terrvision spawns only while the position lies inside a piece of a structure listed in the
 * {@code #terrvision:terrvision_spawn_structures} tag (vanilla mineshafts by default).
 *
 * <p>Fabric's biome API cannot target structures, so the biome entry is added to every Overworld biome and the
 * structure restriction is enforced by the spawn predicate. The weight is kept low, so the cost to vanilla surface
 * spawning (a failed pick wastes one attempt) is negligible.
 */
public final class ModSpawns {

    /** Structures where Terrvision may spawn. Data-driven: add more structure ids to the tag file. */
    public static final TagKey<Structure> SPAWN_STRUCTURES =
            TagKey.of(RegistryKeys.STRUCTURE, Terrvision.id("terrvision_spawn_structures"));

    private ModSpawns() {
    }

    public static void init() {
        SpawnRestriction.register(
                ModEntities.TERRVISION,
                SpawnLocationTypes.ON_GROUND,
                Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                ModSpawns::canSpawn);

        BiomeModifications.addSpawn(
                BiomeSelectors.foundInOverworld(),
                SpawnGroup.CREATURE,
                ModEntities.TERRVISION,
                TerrvisionTuning.SPAWN_WEIGHT,
                1,
                1);
    }

    private static boolean canSpawn(EntityType<TerrvisionEntity> type, ServerWorldAccess world,
                                    SpawnReason reason, BlockPos pos, Random random) {
        // Never during world generation: surface population must not trigger structure lookups.
        if (reason == SpawnReason.CHUNK_GENERATION) {
            return false;
        }
        // Spawners, commands, eggs and other mods are not restricted.
        if (reason != SpawnReason.NATURAL) {
            return true;
        }
        return world instanceof ServerWorld serverWorld && isInsideSpawnStructure(serverWorld, pos);
    }

    /** Piece-level check: true only inside an actual structure piece, not just its expanded bounding box. */
    private static boolean isInsideSpawnStructure(ServerWorld world, BlockPos pos) {
        return world.getStructureAccessor().getStructureContaining(pos, SPAWN_STRUCTURES).hasChildren();
    }
}
