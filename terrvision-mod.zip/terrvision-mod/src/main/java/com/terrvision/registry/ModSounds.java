package com.terrvision.registry;

import com.terrvision.Terrvision;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

/** All sound events of the mod. The actual files are mapped in {@code assets/terrvision/sounds.json}. */
public final class ModSounds {

    public static final SoundEvent TERRVISION_HIT = register("entity.terrvision.hit");
    public static final SoundEvent TERRVISION_SHOP = register("entity.terrvision.shop");
    public static final SoundEvent TERRVISION_WALK = register("entity.terrvision.walk");

    private ModSounds() {
    }

    private static SoundEvent register(String path) {
        Identifier id = Terrvision.id(path);
        return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
    }

    /** Touching this class runs the static initialiser above, which performs the registration. */
    public static void init() {
    }
}
