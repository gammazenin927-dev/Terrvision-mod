package com.terrvision.registry;

import com.terrvision.Terrvision;
import com.terrvision.entity.TerrvisionEntity;
import com.terrvision.entity.TerrvisionTuning;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

/** Entity type registration. */
public final class ModEntities {

    /**
     * CREATURE is deliberate: it is peaceful (never removed on Peaceful difficulty) and,
     * unlike MONSTER, does not need darkness or a hostile-mob cap slot.
     */
    public static final EntityType<TerrvisionEntity> TERRVISION = Registry.register(
            Registries.ENTITY_TYPE,
            Terrvision.id("terrvision"),
            EntityType.Builder.create(TerrvisionEntity::new, SpawnGroup.CREATURE)
                    .dimensions(TerrvisionTuning.WIDTH, TerrvisionTuning.HEIGHT)
                    .eyeHeight(TerrvisionTuning.EYE_HEIGHT)
                    .maxTrackingRange(TerrvisionTuning.TRACKING_RANGE)
                    .build("terrvision"));

    private ModEntities() {
    }

    public static void init() {
        FabricDefaultAttributeRegistry.register(TERRVISION, TerrvisionEntity.createAttributes());
    }
}
