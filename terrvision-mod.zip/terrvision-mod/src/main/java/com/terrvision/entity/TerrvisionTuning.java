package com.terrvision.entity;

/**
 * Single source of truth for every tunable number of the Terrvision entity.
 * Change values here instead of hunting for literals across the code.
 */
public final class TerrvisionTuning {

    private TerrvisionTuning() {
    }

    // --- Hitbox (the model is 2.0 blocks tall at 1:1; the arms make it visually wider than the hitbox) ---
    public static final float WIDTH = 1.25F;
    public static final float HEIGHT = 2.0F;
    public static final float EYE_HEIGHT = 1.75F;
    public static final int TRACKING_RANGE = 10;

    // --- Attributes ---
    public static final double MAX_HEALTH = 80.0D;
    public static final double MOVEMENT_SPEED = 0.28D;
    public static final double KNOCKBACK_RESISTANCE = 0.5D;
    public static final double ARMOR = 6.0D;

    // --- Behaviour ---
    /** Multiplier applied to the movement speed attribute while wandering. */
    public static final double WANDER_SPEED = 0.8D;
    /** Terrvision halts and faces a player closer than this (blocks). */
    public static final double FACE_PLAYER_STOP_RANGE = 2.5D;
    /** ...and only resumes wandering once the player is farther than this (hysteresis avoids stutter). */
    public static final double FACE_PLAYER_RELEASE_RANGE = 3.5D;
    /** Maximum body turn per goal update, in degrees. */
    public static final float FACE_PLAYER_TURN_SPEED = 20.0F;

    // --- Animation / audio ---
    public static final int ANIMATION_TRANSITION_TICKS = 5;
    /** terrvision_walking.ogg is 2.77 s long, so it is re-triggered every ~55 ticks while moving. */
    public static final int WALK_SOUND_INTERVAL_TICKS = 55;
    public static final double WALK_SOUND_MIN_HORIZONTAL_SPEED_SQ = 1.0E-4D;

    // --- Trading ---
    public static final int TRADE_XP_MIN = 3;
    public static final int TRADE_XP_RANDOM_BONUS = 4;

    // --- Spawning (vanilla passive animals use weights of 1-12) ---
    public static final int SPAWN_WEIGHT = 3;
}
