package com.terrvision.entity.ai;

import java.util.EnumSet;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.passive.MerchantEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import org.jetbrains.annotations.Nullable;

/**
 * Makes a merchant stop moving and turn its whole body toward a player.
 *
 * <p>The target is the current trading customer if there is one, otherwise the closest player within
 * {@code stopRange}. Once started, the goal keeps running until the player is farther than {@code releaseRange}
 * (a larger radius than the start radius, so the entity does not flicker between walking and standing).
 *
 * <p>The target reference is cleared in {@link #stop()} so a finished goal never keeps a player alive in memory.
 */
public class FacePlayerGoal extends Goal {

    private final MerchantEntity mob;
    private final double stopRange;
    private final double releaseRangeSq;
    private final float turnSpeed;
    @Nullable
    private PlayerEntity target;

    public FacePlayerGoal(MerchantEntity mob, double stopRange, double releaseRange, float turnSpeed) {
        this.mob = mob;
        this.stopRange = stopRange;
        this.releaseRangeSq = releaseRange * releaseRange;
        this.turnSpeed = turnSpeed;
        this.setControls(EnumSet.of(Goal.Control.MOVE, Goal.Control.LOOK, Goal.Control.JUMP));
    }

    @Override
    public boolean canStart() {
        if (!this.mob.isAlive()) {
            return false;
        }
        PlayerEntity customer = this.mob.getCustomer();
        if (customer != null) {
            this.target = customer;
            return true;
        }
        this.target = this.mob.getWorld().getClosestPlayer(this.mob, this.stopRange);
        return this.target != null;
    }

    @Override
    public boolean shouldContinue() {
        if (!this.mob.isAlive()) {
            return false;
        }
        PlayerEntity customer = this.mob.getCustomer();
        if (customer != null) {
            this.target = customer;
            return true;
        }
        return this.target != null
                && this.target.isAlive()
                && !this.target.isSpectator()
                && this.mob.squaredDistanceTo(this.target) <= this.releaseRangeSq;
    }

    @Override
    public void start() {
        this.mob.getNavigation().stop();
    }

    @Override
    public void stop() {
        this.target = null;
    }

    @Override
    public void tick() {
        if (this.target == null) {
            return;
        }
        double dx = this.target.getX() - this.mob.getX();
        double dz = this.target.getZ() - this.mob.getZ();
        if (dx * dx + dz * dz < 1.0E-4D) {
            return; // standing exactly on top of us: the angle is undefined
        }
        float desiredYaw = (float) (MathHelper.atan2(dz, dx) * (180.0D / Math.PI)) - 90.0F;
        float newYaw = approachAngle(this.mob.getYaw(), desiredYaw, this.turnSpeed);
        // Body, head and entity yaw are kept identical so the model (rendered from body yaw) really faces the player.
        this.mob.setYaw(newYaw);
        this.mob.setBodyYaw(newYaw);
        this.mob.setHeadYaw(newYaw);
    }

    /** Moves {@code current} toward {@code target} by at most {@code maxStep} degrees, taking the shortest way round. */
    private static float approachAngle(float current, float target, float maxStep) {
        float delta = MathHelper.wrapDegrees(target - current);
        return current + MathHelper.clamp(delta, -maxStep, maxStep);
    }
}
