package com.terrvision.entity;

import com.terrvision.entity.ai.FacePlayerGoal;
import com.terrvision.registry.ModSounds;
import com.terrvision.trade.TerrvisionTrades;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.MerchantEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.village.TradeOffer;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.AnimationState;
import software.bernie.geckolib.animation.PlayState;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * Terrvision: a Roosevelt Industrial mining robot turned wandering merchant.
 *
 * <p>Built on vanilla's {@link MerchantEntity}, so the trade screen, XP orbs and offer persistence come for free.
 * Server-side logic (AI, trades, sounds) and client-side animation are separated: the only state shared with the
 * client is the {@link #TRADING} flag, which drives the shop animation.
 */
public class TerrvisionEntity extends MerchantEntity implements GeoEntity {

    /** Synced to clients so the animation controller knows when to play the shop animation. */
    private static final TrackedData<Boolean> TRADING =
            DataTracker.registerData(TerrvisionEntity.class, TrackedDataHandlerRegistry.BOOLEAN);

    // RawAnimation instances are cached: GeckoLib only restarts an animation when the instance changes.
    private static final RawAnimation IDLE_ANIM = RawAnimation.begin().thenLoop("animation.terrvision.idle");
    private static final RawAnimation WALK_ANIM = RawAnimation.begin().thenLoop("animation.terrvision.walk");
    private static final RawAnimation SHOP_ANIM = RawAnimation.begin().thenPlayAndHold("animation.terrvision.shop");

    private final AnimatableInstanceCache animationCache = GeckoLibUtil.createInstanceCache(this);

    /** Server-side countdown until the walking sound may be played again. */
    private int walkSoundCooldown;

    public TerrvisionEntity(EntityType<? extends MerchantEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, TerrvisionTuning.MAX_HEALTH)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, TerrvisionTuning.MOVEMENT_SPEED)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, TerrvisionTuning.KNOCKBACK_RESISTANCE)
                .add(EntityAttributes.GENERIC_ARMOR, TerrvisionTuning.ARMOR);
    }

    // ---------------------------------------------------------------- AI

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(1, new FacePlayerGoal(this,
                TerrvisionTuning.FACE_PLAYER_STOP_RANGE,
                TerrvisionTuning.FACE_PLAYER_RELEASE_RANGE,
                TerrvisionTuning.FACE_PLAYER_TURN_SPEED));
        this.goalSelector.add(2, new WanderAroundFarGoal(this, TerrvisionTuning.WANDER_SPEED));
        this.goalSelector.add(3, new LookAroundGoal(this));
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(TRADING, false);
    }

    // ---------------------------------------------------------------- Trading

    /** @return true while a player has the trade screen open (readable on both logical sides). */
    public boolean isTrading() {
        return this.dataTracker.get(TRADING);
    }

    @Override
    public void setCustomer(@Nullable PlayerEntity customer) {
        boolean wasTrading = this.hasCustomer();
        super.setCustomer(customer);
        if (this.getWorld().isClient) {
            return;
        }
        boolean nowTrading = customer != null;
        this.dataTracker.set(TRADING, nowTrading);
        if (nowTrading && !wasTrading) {
            this.playSound(ModSounds.TERRVISION_SHOP, 1.0F, 1.0F);
        }
    }

    @Override
    public ActionResult interactMob(PlayerEntity player, Hand hand) {
        ItemStack held = player.getStackInHand(hand);
        boolean canTrade = this.isAlive()
                && !this.hasCustomer()
                && !this.isBaby()
                && !player.isSneaking() // sneaking keeps name tags, leads, etc. usable
                && !(held.getItem() instanceof SpawnEggItem);
        if (!canTrade) {
            return super.interactMob(player, hand);
        }

        if (!this.getWorld().isClient) {
            // getOffers() throws on the client, so it must only be touched here.
            if (this.getOffers().isEmpty()) {
                return ActionResult.CONSUME;
            }
            this.setCustomer(player);
            this.sendOffers(player, this.getDisplayName(), 1);
        }
        return ActionResult.success(this.getWorld().isClient);
    }

    /** Called lazily by vanilla the first time offers are needed; reads {@code data/terrvision/trades/terrvision.json}. */
    @Override
    protected void fillRecipes() {
        if (this.getWorld() instanceof ServerWorld serverWorld) {
            this.getOffers().addAll(TerrvisionTrades.load(serverWorld));
        }
    }

    @Override
    protected void afterUsing(TradeOffer offer) {
        if (offer.shouldRewardPlayerExperience()) {
            int xp = TerrvisionTuning.TRADE_XP_MIN + this.random.nextInt(TerrvisionTuning.TRADE_XP_RANDOM_BONUS);
            this.getWorld().spawnEntity(
                    new ExperienceOrbEntity(this.getWorld(), this.getX(), this.getY() + 0.5D, this.getZ(), xp));
        }
    }

    @Override
    public @Nullable PassiveEntity createChild(ServerWorld world, PassiveEntity entity) {
        return null; // robots do not breed
    }

    /** Like animals, Terrvision never despawns just because the player walked away. */
    @Override
    public boolean canImmediatelyDespawn(double distanceSquared) {
        return false;
    }

    // ---------------------------------------------------------------- Sounds

    @Override
    public void tick() {
        super.tick();
        if (!this.getWorld().isClient) {
            this.tickWalkSound();
        }
    }

    /** Plays the (2.77 s) walking clip, then waits for it to finish before it may be played again. */
    private void tickWalkSound() {
        if (this.walkSoundCooldown > 0) {
            this.walkSoundCooldown--;
            return;
        }
        boolean walking = this.isOnGround()
                && this.getVelocity().horizontalLengthSquared() > TerrvisionTuning.WALK_SOUND_MIN_HORIZONTAL_SPEED_SQ;
        if (walking) {
            this.playSound(ModSounds.TERRVISION_WALK, 1.0F, 1.0F);
            this.walkSoundCooldown = TerrvisionTuning.WALK_SOUND_INTERVAL_TICKS;
        }
    }

    @Override
    protected @Nullable SoundEvent getHurtSound(DamageSource source) {
        return ModSounds.TERRVISION_HIT;
    }

    /** No dedicated death clip was supplied, so the hit sound is reused. */
    @Override
    protected @Nullable SoundEvent getDeathSound() {
        return ModSounds.TERRVISION_HIT;
    }

    // Metallic placeholders so a robot never makes villager "hmm"/"yes" noises while trading.
    @Override
    public SoundEvent getYesSound() {
        return SoundEvents.ENTITY_IRON_GOLEM_REPAIR;
    }

    @Override
    protected SoundEvent getTradingSound(boolean sold) {
        return sold ? SoundEvents.ENTITY_IRON_GOLEM_REPAIR : SoundEvents.ENTITY_IRON_GOLEM_STEP;
    }

    // ---------------------------------------------------------------- GeckoLib

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(
                this, "main", TerrvisionTuning.ANIMATION_TRANSITION_TICKS, this::animationState));
    }

    /**
     * Priority: shop (while trading) > walk (while moving) > idle. When trading ends the controller simply
     * falls back to idle/walk, which is how the held shop pose is "reset".
     */
    private PlayState animationState(AnimationState<TerrvisionEntity> state) {
        if (this.isTrading()) {
            return state.setAndContinue(SHOP_ANIM);
        }
        return state.setAndContinue(state.isMoving() ? WALK_ANIM : IDLE_ANIM);
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.animationCache;
    }
}
