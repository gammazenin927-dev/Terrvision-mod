package com.terrvision.client;

import com.terrvision.client.render.TerrvisionRenderer;
import com.terrvision.registry.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

/** Client-only entrypoint: everything that touches rendering is registered here and nowhere else. */
@Environment(EnvType.CLIENT)
public final class TerrvisionClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.TERRVISION, TerrvisionRenderer::new);
    }
}
