package com.terrvision.client.render;

import com.terrvision.Terrvision;
import com.terrvision.entity.TerrvisionEntity;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.EntityRendererFactory;
import software.bernie.geckolib.model.DefaultedEntityGeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

/**
 * Renders Terrvision with GeckoLib. {@link DefaultedEntityGeoModel} resolves the assets by convention from the id:
 * <ul>
 *   <li>{@code assets/terrvision/geo/entity/terrvision.geo.json}</li>
 *   <li>{@code assets/terrvision/animations/entity/terrvision.animation.json}</li>
 *   <li>{@code assets/terrvision/textures/entity/terrvision.png}</li>
 * </ul>
 */
@Environment(EnvType.CLIENT)
public class TerrvisionRenderer extends GeoEntityRenderer<TerrvisionEntity> {

    private static final float SHADOW_RADIUS = 0.7F;

    public TerrvisionRenderer(EntityRendererFactory.Context context) {
        super(context, new DefaultedEntityGeoModel<>(Terrvision.id("terrvision")));
        this.shadowRadius = SHADOW_RADIUS;
    }
}
